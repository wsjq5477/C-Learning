/***************************************************************************
    �ļ�����: main.c

    ����:     ���ܳ���Ŀ����ͷ��

    �汾:     2016-11-04
    
    ˵��:     

    �޸ļ�¼: ��
***************************************************************************/

#include <hidef.h>           /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "System_Init.h"
#include "Image.h"
#include "Route.h"
#include "SCI.h"
#include "PID.h"

extern unsigned char black_line[40];

//=====================================================================================
void main(void) 
{   
    
    Sys_Init();
    delay(10000);            
     
    for(;;) 
    {
        
        //send_image();
        //send_line();
        //get_line();               
        //route_judge();
        steer_PD();
        /***********�򵥲��Զ��*******************      
        
        binaryzation();          //��ֵ������
        
        route_extract();         //������ȡ
        
        if(black_line[32]-black_line[12]>2) //�����
        {
            delay(5);            
            PWMDTY67=1530;           
        }      
        if(black_line[12]-black_line[32]>2) //�����
        {
            delay(5);
            PWMDTY67=1100;
        } 
        if(black_line[32]-black_line[12]<2||black_line[12]-black_line[32]<2)
        {
            delay(5);     
            PWMDTY67=1370;           
        } 
        **/
       
    }
}
 

