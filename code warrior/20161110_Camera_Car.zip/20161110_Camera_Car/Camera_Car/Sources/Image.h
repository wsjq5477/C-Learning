/********************************
Image.H

ͼ��ɼ��봦����ͷ�ļ�
********************************/

#ifndef _Image_H_
#define _Image_H_

//***************��������*************//
extern void delay(unsigned int num);
extern void binaryzation(void);
extern void route_extract(void);
extern void send_image(void);
extern void send_line(void);
extern void get_line(void);

#endif