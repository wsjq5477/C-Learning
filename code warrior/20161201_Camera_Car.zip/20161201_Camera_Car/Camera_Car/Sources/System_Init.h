/********************************
System_Init.H

MC9S08AW60 sys_init0ģ���ͷ�ļ�
********************************/

#ifndef _SYSTEM_INIT_H_
#define _SYSTEM_INIT_H_

//***************��������*************//
extern void Sys_Init(void); 
void TIM_Init(void);
void PWM_Init(void); 

#endif